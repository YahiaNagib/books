# MyReads Project

This is a book app where you can store your favorite books and search of tens of others. You can store 
the books under three categories: currently reading, want to read and read. 
A book can be moved from one shelf to another.
You can search your required book and add it to the shelf.

## TL;DR

To get started developing right away:

* install all project dependencies with `npm install`
* start the development server with `npm start`

## How to use
Each book has a number of options where you can change its shelf.
To search a certain book, click on the button at the lower right corner to open the search page
then type your query.
